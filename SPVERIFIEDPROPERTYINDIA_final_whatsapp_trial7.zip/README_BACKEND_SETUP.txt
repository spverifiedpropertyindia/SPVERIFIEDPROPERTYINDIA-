BACKEND SETUP (Firebase Cloud Functions + Razorpay)

1) Install Firebase CLI
   npm i -g firebase-tools

2) Login
   firebase login

3) Initialize Functions (if needed)
   firebase init functions

4) Copy this /functions folder (already included)

5) Install deps
   cd functions
   npm install

6) Set Razorpay keys (IMPORTANT)
   firebase functions:config:set razorpay.key_id="rzp_live_xxx" razorpay.key_secret="xxx"

7) Deploy
   firebase deploy --only functions

Endpoints created:
- POST https://<region>-<project>.cloudfunctions.net/createRazorpayOrder
- POST https://<region>-<project>.cloudfunctions.net/verifyRazorpayPayment

After that, update payment.html / vpi.js to call createRazorpayOrder first,
then on handler call verifyRazorpayPayment.
