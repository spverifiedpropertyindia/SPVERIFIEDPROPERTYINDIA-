ADMIN SETUP (SPVERIFIEDPROPERTYINDIA)

✅ Admin access will work ONLY for:
1) Email allow-list in vpi.js -> ADMIN_EMAILS
OR
2) Firestore: system/admins/{uid} => { active: true }

Recommended: Use Firestore (option 2) for scalable admin control.

Example doc path:
system/admins/<USER_UID>

Example document:
{
  "active": true,
  "role": "admin"
}
