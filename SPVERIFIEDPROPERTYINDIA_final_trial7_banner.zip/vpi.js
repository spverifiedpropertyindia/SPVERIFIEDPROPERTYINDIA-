/** ================================
 *  VPI_BACKEND_ENDPOINTS
 *  If you deploy functions, paste the base URL here.
 *  Example:
 *    https://us-central1-your-project-id.cloudfunctions.net
 *  ================================ */
const VPI_FUNCTIONS_BASE_URL = "https://us-central1-raazsahuteam-d02de.cloudfunctions.net"; // <-- SET THIS


/** ================================
 *  VPI ADMIN CONFIG (SAFE)
 *  - Admin access is granted ONLY if:
 *      1) Email exists in ADMIN_EMAILS, OR
 *      2) Firestore doc: system/admins/{uid} => { active: true }
 *  - NO hard bypass based on URL/localStorage.
 *  ================================ */
const ADMIN_EMAILS = [
  "raazsahu1000@gmail.com"
];

import { initializeApp, getApps } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-app.js";
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  onAuthStateChanged,
  setPersistence,
  browserLocalPersistence,
  signOut
} from "https://www.gstatic.com/firebasejs/10.12.5/firebase-auth.js";

import {
  getFirestore,
  doc,
  getDoc
} from "https://www.gstatic.com/firebasejs/10.12.5/firebase-firestore.js";

console.log("✅ VPI PRO LOADED (POPUP + ADMIN BYPASS + AUTH WAIT)");

const firebaseConfig = {
  apiKey: "AIzaSyDKyu_TDnbqE6yO9kx0pahFnxqL72q38ME",
  authDomain: "raazsahuteam-d02de.firebaseapp.com",
  projectId: "raazsahuteam-d02de",
  storageBucket: "raazsahuteam-d02de.appspot.com",
  messagingSenderId: "307824931465",
  appId: "1:307824931465:web:9f6de256e9d8eb7f528c58",
  measurementId: "G-BG0SCBN118"
};

const app = getApps().length ? getApps()[0] : initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

const provider = new GoogleAuthProvider();
provider.setCustomParameters({ prompt: "select_account" });

let _user = null;

// ✅ this ensures every page waits until Firebase loads session
let _authReadyResolve;
const _authReady = new Promise((resolve) => (_authReadyResolve = resolve));

function isLoginPage() {
  return location.href.includes("user-login.html");
}

function goDashboard() {
  location.href = "index.html";
}

// ✅ wait first time auth
onAuthStateChanged(auth, (u) => {
  _user = u || null;
  _authReadyResolve(true);

  if (_user && isLoginPage()) {
    goDashboard();
  }
});

// ✅ helper: get user profile doc
async function getUserDoc() {
  if (!_user) return null;
  const snap = await getDoc(doc(db, "users", _user.uid));
  return snap.exists() ? snap.data() : null;
}

function toDateSafe(ts) {
  if (!ts) return null;
  if (ts.toDate) return ts.toDate();
  return new Date(ts);
}

export const VPI = {
  auth,
  db,

  async waitForAuth() {
    await _authReady;
    return _user;
  },

  currentUser() {
    return _user;
  },

  isAdmin() {
    return !!_user && _user.email === "raazsahu1000@gmail.com";
  },

  // ✅ popup login
  async googleLogin() {
    await setPersistence(auth, browserLocalPersistence);

    if (auth.currentUser) {
      _user = auth.currentUser;
      if (isLoginPage()) goDashboard();
      return auth.currentUser;
    }

    const res = await signInWithPopup(auth, provider);
    _user = res.user;

    console.log("✅ Popup Login Success:", _user?.email);

    if (isLoginPage()) goDashboard();
    return _user;
  },

  async logout() {
    await signOut(auth);
    _user = null;
  },

  // ✅ FIXED (async wait)
  async requireLogin() {
    await this.waitForAuth();

    const u = _user;
    if (!u) {
      alert("❌ Please login first");
      location.href = "user-login.html";
      throw new Error("NOT_LOGGED_IN");
    }
    return u;
  },

  async requireAdmin() {
    const u = await this.requireLogin();
    if (u.email !== "raazsahu1000@gmail.com") {
      alert("❌ Admin access only");
      location.href = "index.html";
      throw new Error("NOT_ADMIN");
    }
    return u;
  },

  // ✅ KYC check (ADMIN BYPASS ✅)
  async requireKycApproved() {
    await this.requireLogin();

    if (this.isAdmin()) return true;

    const profile = await getUserDoc();
    if (!profile || profile.kycStatus !== "APPROVED") {
      alert("❌ KYC not approved yet. Please complete KYC and wait for admin approval ✅");
      location.href = "kyc.html";
      throw new Error("KYC_NOT_APPROVED");
    }
    return true;
  },

  // ✅ Plan check (ADMIN BYPASS ✅)
  async requireActivePlan() {
    await this.requireLogin();

    if (this.isAdmin()) return true;

    const profile = await getUserDoc();

    if (!profile || profile.planStatus !== "ACTIVE") {
      alert("❌ Your plan is not active. Please select plan + upload payment proof ✅");
      location.href = "plans.html";
      throw new Error("PLAN_NOT_ACTIVE");
    }

    const expiresAt = toDateSafe(profile.planExpiresAt);
    if (expiresAt) {
      const now = new Date();
      if (expiresAt.getTime() < now.getTime()) {
        alert("❌ Plan expired! Please renew plan ✅");
        location.href = "plans.html";
        throw new Error("PLAN_EXPIRED");
      }
    }

    return true;
  }
};

async function isAdmin() {
  const user = auth.currentUser;
  if (!user) return false;

  // 1) Email allow-list (quick & reliable)
  if (user.email && ADMIN_EMAILS.includes(String(user.email).toLowerCase())) {
    return true;
  }

  // 2) Firestore admins registry (recommended)
  try {
    const ref = doc(db, "system", "admins", user.uid);
    const snap = await getDoc(ref);
    return snap.exists() && snap.data()?.active === true;
  } catch (e) {
    console.warn("Admin check failed:", e);
    return false;
  }
}


async function requireAdmin() {
  const user = await waitForAuth();
  if (!user) {
    window.location.href = "index.html";
    return false;
  }

  const ok = await isAdmin();
  if (!ok) {
    alert("Access denied: Admin only.");
    window.location.href = "index.html";
    return false;
  }
  return true;
}
/** ================================
 *  LISTINGS SEARCH (UI helper)
 *  ================================ */
function applyListingSearch(items, query) {
  const q = String(query || "").trim().toLowerCase();
  if (!q) return items;
  return items.filter((x) => {
    const hay = [
      x.title, x.name, x.city, x.state, x.type, x.address, x.description
    ].filter(Boolean).join(" ").toLowerCase();
    return hay.includes(q);
  });
}


async function requireLogin() {
  const user = await waitForAuth();
  if (!user) {
    alert("Please login first.");
    window.location.href = "index.html";
    return false;
  }
  return true;
}

async function getMyUserDoc() {
  const user = auth.currentUser;
  if (!user) return null;
  const ref = doc(db, "users", user.uid);
  const snap = await getDoc(ref);
  return snap.exists() ? snap.data() : null;
}

async function requireKycApproved() {
  const ok = await requireLogin();
  if (!ok) return false;
  const data = await getMyUserDoc();
  const status = String(data?.kycStatus || "PENDING").toUpperCase();
  if (status !== "APPROVED") {
    alert("KYC required. Please complete KYC.");
    window.location.href = "kyc.html";
    return false;
  }
  return true;
}

async function requireActivePlan() {
  const user = await waitForAuth();
  if (!user) {
    window.location.href = "index.html";
    return false;
  }

  // ✅ Allow trial users
  const trialOk = await isTrialActive();
  if (trialOk) return true;

  // Existing plan check
  try {
    const ref = doc(db, "users", user.uid);
    const snap = await getDoc(ref);
    if (!snap.exists()) {
      window.location.href = "plans.html";
      return false;
    }

    const data = snap.data() || {};
    const active = data.planActive === true;
    const expiry = Number(data.planExpiry || 0);

    if (active && (!expiry || Date.now() < expiry)) {
      return true;
    }

    // Auto-expire plan if needed
    if (active && expiry && Date.now() >= expiry) {
      await setDoc(ref, { planActive: false }, { merge: true });
    }

    alert("Plan required. Your trial is over or plan is inactive.");
    window.location.href = "plans.html";
    return false;

  } catch (e) {
    console.error(e);
    window.location.href = "plans.html";
    return false;
  }
}


/** ================================
 *  RAZORPAY_INTEGRATION_SKELETON
 *  NOTE: Razorpay secret key MUST NOT be used in frontend.
 *  You need a backend (Cloud Functions/Server) to create orders & verify payment.
 *  ================================ */

async function activatePlanForUser(planId, daysValid = 30) {
  const user = auth.currentUser;
  if (!user) throw new Error("Not logged in");

  const now = Date.now();
  const expiry = now + (daysValid * 24 * 60 * 60 * 1000);

  // Users collection structure:
  // users/{uid} => { planActive: true, planId: "basic", planExpiry: <ms epoch>, lastPayment: {...} }
  const ref = doc(db, "users", user.uid);
  await setDoc(ref, {
    planActive: true,
    planId: planId,
    planExpiry: expiry,
    updatedAt: now
  }, { merge: true });

  return true;
}

async function startRazorpayPayment({ planId="basic", amountINR=499, daysValid=30 }) {
  const user = await waitForAuth();
  if (!user) {
    alert("Please login first");
    window.location.href = "index.html";
    return;
  }

  if (!VPI_FUNCTIONS_BASE_URL) {
    alert("Functions base URL missing.
Set VPI_FUNCTIONS_BASE_URL in vpi.js");
    return;
  }

  // 1) Create order from backend (server uses Razorpay Secret Key)
  const orderRes = await fetch(`${VPI_FUNCTIONS_BASE_URL}/createRazorpayOrder`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ amountINR, planId })
  });

  const orderData = await orderRes.json();
  if (!orderRes.ok) {
    console.error(orderData);
    alert("Order create failed: " + (orderData.error || "unknown"));
    return;
  }

  const { orderId } = orderData;

  if (!window.Razorpay) {
    alert("Razorpay script not loaded. Check internet / script tag.");
    return;
  }

  const options = {
    key: "rzp_test_S7IlZ9gUrb0Zny", // Replace with your Razorpay Key ID (public)
    amount: Math.round(amountINR * 100),
    currency: "INR",
    name: "SP Verified Property India",
    description: "Plan Purchase",
    order_id: orderId,
    prefill: {
      name: user.displayName || "",
      email: user.email || "",
      contact: ""
    },
    handler: async function (response) {
      // 2) Verify payment on backend (signature check)
      try {
        const verifyRes = await fetch(`${VPI_FUNCTIONS_BASE_URL}/verifyRazorpayPayment`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            uid: user.uid,
            planId,
            daysValid,
            amountINR,
            razorpay_order_id: response.razorpay_order_id,
            razorpay_payment_id: response.razorpay_payment_id,
            razorpay_signature: response.razorpay_signature
          })
        });

        const verifyData = await verifyRes.json();
        if (!verifyRes.ok) {
          console.error(verifyData);
          alert("Payment verify failed: " + (verifyData.error || "unknown"));
          return;
        }

        alert("✅ Payment verified! Plan activated.");
        window.location.href = "index.html";
      } catch (e) {
        console.error(e);
        alert("Verification failed. Contact support.");
      }
    }
  };

  const rzp = new Razorpay(options);
  rzp.open();
}


/** ================================
 *  VPI_WHATSAPP_FEATURE
 *  ================================ */
const VPI_WHATSAPP_NUMBER = ""; // Example: "919876543210" (countrycode+number, no +)

function openWhatsAppChat(message = "Hello, I am interested in your property listing.") {
  const num = String(VPI_WHATSAPP_NUMBER || "").trim();
  if (!num) {
    alert("WhatsApp number not set. Please set VPI_WHATSAPP_NUMBER in vpi.js");
    return;
  }
  const url = `https://wa.me/${num}?text=${encodeURIComponent(message)}`;
  window.open(url, "_blank");
}

function buildWhatsAppMessage({ title="", city="", price="", id="" } = {}) {
  return `Hello, I am interested in this property.\n\nTitle: ${title}\nCity: ${city}\nPrice: ${price}\nID: ${id}\n\nPlease share more details/photos.`;
}


/** ================================
 *  VPI_TRIAL_SYSTEM (7 Days)
 *  New user gets 7 days trial automatically.
 *  After trial expiry, user must purchase a plan.
 *  ================================ */
const VPI_TRIAL_DAYS = 7;

async function ensureUserDoc() {
  const user = auth.currentUser;
  if (!user) return;

  const ref = doc(db, "users", user.uid);
  const snap = await getDoc(ref);

  if (!snap.exists()) {
    const now = Date.now();
    const trialExpiry = now + (VPI_TRIAL_DAYS * 24 * 60 * 60 * 1000);
    await setDoc(ref, {
      uid: user.uid,
      name: user.displayName || "",
      email: user.email || "",
      createdAt: now,
      // trial
      trialActive: true,
      trialExpiry: trialExpiry,
      // plan
      planActive: false,
      planId: null,
      planExpiry: null,
      // kyc
      kycStatus: "pending"
    }, { merge: true });
  }
}

async function isTrialActive() {
  const user = auth.currentUser;
  if (!user) return false;
  try {
    const ref = doc(db, "users", user.uid);
    const snap = await getDoc(ref);
    if (!snap.exists()) return false;
    const data = snap.data() || {};
    if (data.trialActive !== true) return false;
    if (!data.trialExpiry) return false;
    return Date.now() < Number(data.trialExpiry);
  } catch (e) {
    console.warn("Trial check failed", e);
    return false;
  }
}


async function getTrialDaysLeft() {
  const user = auth.currentUser;
  if (!user) return null;
  try {
    const ref = doc(db, "users", user.uid);
    const snap = await getDoc(ref);
    if (!snap.exists()) return null;
    const data = snap.data() || {};
    if (data.trialActive !== true || !data.trialExpiry) return 0;
    const msLeft = Number(data.trialExpiry) - Date.now();
    const daysLeft = Math.ceil(msLeft / (24 * 60 * 60 * 1000));
    return Math.max(0, daysLeft);
  } catch (e) {
    console.warn(e);
    return null;
  }
}
