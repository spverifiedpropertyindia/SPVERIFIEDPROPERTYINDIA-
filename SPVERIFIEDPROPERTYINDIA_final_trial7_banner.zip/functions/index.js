/**
 * SPVERIFIEDPROPERTYINDIA - Firebase Cloud Functions (Razorpay)
 *
 * ✅ Provides:
 * 1) createRazorpayOrder  (Callable HTTPS)
 * 2) verifyRazorpayPayment (Callable HTTPS)
 *
 * IMPORTANT:
 * - Set Razorpay keys using Firebase config:
 *   firebase functions:config:set razorpay.key_id="rzp_live_xxx" razorpay.key_secret="xxx"
 * - Deploy: firebase deploy --only functions
 */

const functions = require("firebase-functions");
const admin = require("firebase-admin");
const Razorpay = require("razorpay");
const cors = require("cors")({ origin: true });
const crypto = require("crypto");

admin.initializeApp();

function getRazorpayClient() {
  const key_id = functions.config().razorpay?.key_id;
  const key_secret = functions.config().razorpay?.key_secret;

  if (!key_id || !key_secret) {
    throw new Error("Razorpay keys not configured. Run: firebase functions:config:set razorpay.key_id=... razorpay.key_secret=...");
  }

  return new Razorpay({ key_id, key_secret });
}

/**
 * createRazorpayOrder
 * Request:
 *  { amountINR: number, planId: string }
 * Response:
 *  { orderId, amount, currency }
 */
exports.createRazorpayOrder = functions.https.onRequest((req, res) => {
  cors(req, res, async () => {
    try {
      if (req.method !== "POST") return res.status(405).json({ error: "Use POST" });

      const { amountINR, planId } = req.body || {};
      const amount = Math.round(Number(amountINR || 0) * 100);
      if (!amount || amount < 100) return res.status(400).json({ error: "Invalid amountINR" });

      const razorpay = getRazorpayClient();

      const order = await razorpay.orders.create({
        amount,
        currency: "INR",
        receipt: `vpi_${Date.now()}`,
        notes: { planId: String(planId || "basic") }
      });

      return res.json({ orderId: order.id, amount: order.amount, currency: order.currency });
    } catch (e) {
      console.error(e);
      return res.status(500).json({ error: e.message });
    }
  });
});

/**
 * verifyRazorpayPayment
 * Request:
 *  { razorpay_order_id, razorpay_payment_id, razorpay_signature, planId, daysValid }
 *
 * - Verifies signature
 * - Activates plan in Firestore for the authenticated user (uid provided in request)
 */
exports.verifyRazorpayPayment = functions.https.onRequest((req, res) => {
  cors(req, res, async () => {
    try {
      if (req.method !== "POST") return res.status(405).json({ error: "Use POST" });

      const {
        razorpay_order_id,
        razorpay_payment_id,
        razorpay_signature,
        uid,
        planId = "basic",
        daysValid = 30,
        amountINR = null
      } = req.body || {};

      if (!uid) return res.status(400).json({ error: "uid required" });

      const key_secret = functions.config().razorpay?.key_secret;
      if (!key_secret) throw new Error("razorpay.key_secret missing in functions config");

      const body = `${razorpay_order_id}|${razorpay_payment_id}`;
      const expected = crypto.createHmac("sha256", key_secret).update(body.toString()).digest("hex");

      if (expected !== razorpay_signature) {
        return res.status(400).json({ error: "Signature mismatch" });
      }

      const now = Date.now();
      const expiry = now + (Number(daysValid) * 24 * 60 * 60 * 1000);

      await admin.firestore().collection("users").doc(uid).set({
        planActive: true,
        planId: String(planId),
        planExpiry: expiry,
        updatedAt: now
      }, { merge: true });

      // store payment
      await admin.firestore().collection("payments").doc(String(razorpay_payment_id)).set({
        uid,
        planId: String(planId),
        daysValid: Number(daysValid),
        amountINR,
        razorpay_order_id,
        razorpay_payment_id,
        razorpay_signature,
        status: "verified_server_side",
        createdAt: now
      }, { merge: true });

      return res.json({ ok: true, message: "Payment verified & plan activated" });
    } catch (e) {
      console.error(e);
      return res.status(500).json({ error: e.message });
    }
  });
});
