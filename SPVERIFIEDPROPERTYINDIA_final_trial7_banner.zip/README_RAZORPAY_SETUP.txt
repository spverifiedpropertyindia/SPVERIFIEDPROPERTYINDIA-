RAZORPAY SETUP (Skeleton Added)

✅ payment.html has Razorpay Checkout script
✅ Pay button calls startRazorpayPayment()

IMPORTANT (Production):
1) Create order on backend using Razorpay Secret Key
2) Verify payment signature on backend
3) Only then activate plan (planActive=true)

In vpi.js:
- Replace key: "rzp_test_YOUR_KEY_HERE"
- Replace dummy order flow with real backend call
