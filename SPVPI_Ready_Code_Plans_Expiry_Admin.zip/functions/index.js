const functions = require("firebase-functions");
const admin = require("firebase-admin");
const Razorpay = require("razorpay");
const cors = require("cors")({ origin: true });
const crypto = require("crypto");

admin.initializeApp();
const db = admin.firestore();

/** ✅ FINAL PLANS CONFIG */
const PLANS = {
  owner: {
    basic: { price: 0, listingsPerMonth: 2, validityDays: 28 },
    standard: { price: 299, listingsPerMonth: 5, validityDays: 56 },
    premium: { price: 499, listingsPerMonth: 10, validityDays: 84 },
  },
  broker: {
    basic: { price: 0, listingsPerMonth: 4, validityDays: 28 },
    standard: { price: 499, listingsPerMonth: 25, validityDays: 56 },
    premium: { price: 699, listingsPerMonth: -1, validityDays: 84 }, // unlimited
  },
};

function getRazorpayClient() {
  const key_id = functions.config().razorpay?.key_id;
  const key_secret = functions.config().razorpay?.key_secret;

  if (!key_id || !key_secret) {
    throw new Error(
      "Razorpay keys missing. Run: firebase functions:config:set razorpay.key_id='xxx' razorpay.key_secret='xxx'"
    );
  }

  return new Razorpay({ key_id, key_secret });
}

function planExpiryMs(validityDays) {
  return Date.now() + Number(validityDays) * 24 * 60 * 60 * 1000;
}

/**
 * ✅ 1) Create Razorpay Order
 * Body: { amountINR, role, planId }
 */
exports.createRazorpayOrder = functions.https.onRequest((req, res) => {
  cors(req, res, async () => {
    try {
      if (req.method !== "POST") return res.status(405).json({ error: "Use POST" });

      const { amountINR, role, planId } = req.body || {};
      const selectedPlan = PLANS?.[role]?.[planId];

      if (!selectedPlan) return res.status(400).json({ error: "Invalid role/planId" });

      // ✅ Amount mismatch block
      if (Number(amountINR) !== Number(selectedPlan.price)) {
        return res.status(400).json({
          error: `Amount mismatch. Expected ₹${selectedPlan.price} for ${role}-${planId}`,
        });
      }

      const amount = Math.round(Number(amountINR || 0) * 100);
      if (!amount || amount < 100) return res.status(400).json({ error: "Invalid amount" });

      const razorpay = getRazorpayClient();

      const order = await razorpay.orders.create({
        amount,
        currency: "INR",
        receipt: `spvpi_${Date.now()}`,
        notes: { role: String(role), planId: String(planId) },
      });

      return res.json({
        orderId: order.id,
        amount: order.amount,
        currency: order.currency,
      });
    } catch (e) {
      console.error(e);
      return res.status(500).json({ error: e.message });
    }
  });
});

/**
 * ✅ 2) Verify Razorpay Payment + Activate Plan + Properties LIVE
 * Body:
 * {
 *  razorpay_order_id, razorpay_payment_id, razorpay_signature,
 *  uid, role, planId, amountINR
 * }
 */
exports.verifyRazorpayPayment = functions.https.onRequest((req, res) => {
  cors(req, res, async () => {
    try {
      if (req.method !== "POST") return res.status(405).json({ error: "Use POST" });

      const {
        razorpay_order_id,
        razorpay_payment_id,
        razorpay_signature,
        uid,
        role,
        planId,
        amountINR,
      } = req.body || {};

      if (!uid) return res.status(400).json({ error: "uid required" });

      const selectedPlan = PLANS?.[role]?.[planId];
      if (!selectedPlan) return res.status(400).json({ error: "Invalid role/planId" });

      // ✅ Amount mismatch block
      if (Number(amountINR) !== Number(selectedPlan.price)) {
        return res.status(400).json({
          error: `Amount mismatch. Expected ₹${selectedPlan.price} for ${role}-${planId}`,
        });
      }

      const key_secret = functions.config().razorpay?.key_secret;
      if (!key_secret) throw new Error("razorpay.key_secret missing");

      // ✅ Signature verify
      const body = `${razorpay_order_id}|${razorpay_payment_id}`;
      const expected = crypto.createHmac("sha256", key_secret).update(body.toString()).digest("hex");

      if (expected !== razorpay_signature) {
        return res.status(400).json({ error: "Signature mismatch" });
      }

      const now = Date.now();
      const expiry = planExpiryMs(selectedPlan.validityDays);

      // ✅ Save user plan
      await db.collection("users").doc(uid).set(
        {
          role,

          planActive: true,
          planId: String(planId),
          planExpiry: Number(expiry),

          plan: {
            planName: String(planId),
            price: Number(selectedPlan.price),
            listingsPerMonth: Number(selectedPlan.listingsPerMonth),
            validityDays: Number(selectedPlan.validityDays),
            startAt: admin.firestore.Timestamp.fromMillis(now),
            endAt: admin.firestore.Timestamp.fromMillis(expiry),
            isActive: true,
          },

          updatedAt: now,
        },
        { merge: true }
      );

      // ✅ Save payment record
      await db.collection("payments").doc(String(razorpay_payment_id)).set(
        {
          uid,
          role: String(role),
          planId: String(planId),
          validityDays: Number(selectedPlan.validityDays),
          amountINR: Number(amountINR),
          razorpay_order_id,
          razorpay_payment_id,
          razorpay_signature,
          status: "verified_server_side",
          createdAt: now,
        },
        { merge: true }
      );

      /**
       ✅ IMPORTANT FIX:
       Property me user field `uid` bhi ho sakta hai OR `userId` bhi
       isliye dono update kar rahe hain ✅
       */
      const snapUid = await db.collection("properties").where("uid", "==", uid).get();
      const snapUserId = await db.collection("properties").where("userId", "==", uid).get();

      const batch = db.batch();

      snapUid.forEach((doc) => {
        batch.update(doc.ref, {
          liveStatus: "LIVE",
          isVisible: true,
          liveUntil: expiry,
          updatedAt: admin.firestore.FieldValue.serverTimestamp(),
        });
      });

      snapUserId.forEach((doc) => {
        batch.update(doc.ref, {
          liveStatus: "LIVE",
          isVisible: true,
          liveUntil: expiry,
          updatedAt: admin.firestore.FieldValue.serverTimestamp(),
        });
      });

      await batch.commit();

      return res.json({
        ok: true,
        message: "✅ Plan Activated + Properties LIVE again",
        updatedProperties: snapUid.size + snapUserId.size,
      });
    } catch (e) {
      console.error(e);
      return res.status(500).json({ error: e.message });
    }
  });
});

/**
 * ✅ 3) AUTO EXPIRE PROPERTIES (Daily 1 AM)
 * LIVE → EXPIRED + Hide
 */
exports.autoExpirePropertiesDaily = functions.pubsub
  .schedule("every day 01:00")
  .timeZone("Asia/Kolkata")
  .onRun(async () => {
    try {
      const now = Date.now();

      const snap = await db
        .collection("properties")
        .where("liveStatus", "==", "LIVE")
        .where("liveUntil", "<=", now)
        .get();

      if (snap.empty) {
        console.log("✅ No properties to expire today.");
        return null;
      }

      const batch = db.batch();

      snap.forEach((doc) => {
        batch.update(doc.ref, {
          liveStatus: "EXPIRED",
          isVisible: false,
          updatedAt: admin.firestore.FieldValue.serverTimestamp(),
        });
      });

      await batch.commit();

      console.log(`✅ Expired properties: ${snap.size}`);
      return null;
    } catch (e) {
      console.error("autoExpirePropertiesDaily error:", e);
      return null;
    }
  });
